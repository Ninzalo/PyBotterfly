from setuptools import setup, find_packages

setup(
    name="pybotterfly",
    version="0.0.1",
    url="https://github.com/Ninzalo/PyBotterfly",
    license="MIT",
    author="Ninzalo",
    packages=find_packages(),
    zip_safe=False,
)
